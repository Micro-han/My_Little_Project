<h1 align="center">Chinese Checkers</h1>
<h3 align="center">python game</h3>

## Introduction
Create a chinese checkers game with pygame.

## Usage
  - Install requirements :
  python 3
  
  ```Git
    git clone https://github.com/nourelhouda-taroudi/Chinese-checkers.git
    cd Chinese-checkers
  ```
## Example
<div align="center">
    <img alt="welcome" src="https://i.imgur.com/8VFp11C.png" width=70%">
</div>
