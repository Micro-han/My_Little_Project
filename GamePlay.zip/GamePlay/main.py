from reversi import *


if __name__ == '__main__':
    reversi.reversi()