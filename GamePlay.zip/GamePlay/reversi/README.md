# reversi-game
Reversi game in python
