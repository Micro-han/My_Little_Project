## common parameters used in the game
BLACK_CELL = 0
WHITE_CELL = 1
EMPTY_CELL = -1
SIDE_LEN = 8

## parameters allow the board class to get the 
## valid moves and update the grid after a move
DIR_COUNT = 8
dx = [-1, -1, -1, 0, 0, 1, 1, 1]
dy = [-1, 0, 1, -1, 1, -1, 0, 1]
